package com.DSchool.DSchool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DSchoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
