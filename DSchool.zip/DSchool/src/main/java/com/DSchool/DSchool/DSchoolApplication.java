package com.DSchool.DSchool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(DSchoolApplication.class, args);
	}

}
